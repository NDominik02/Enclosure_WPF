﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Bekerites_WPF.ViewModel
{
    public class ViewModelBase : INotifyPropertyChanged
    {
        //Nézetmodell ősosztály példányosítása.
        protected ViewModelBase() { }

        //Tulajdonság változásának eseménye.
        public event PropertyChangedEventHandler? PropertyChanged;

        //Tulajdonság változása ellenőrzéssel.
        protected virtual void OnPropertyChanged([CallerMemberName] String? propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
