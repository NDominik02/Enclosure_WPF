﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Drawing;
using Bekerites.Model;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace Bekerites_WPF.ViewModel
{
    public class BekeritesViewModel : ViewModelBase
    {
        #region Fields

        private BekeritesGameModel _model;

        private Int32 _size;

        private Int32 _occupiedAreaR = 0;
        private Int32 _occupiedAreaB = 0;

        private BekeritesField? currentField = null;
        private BekeritesField? previouslyPainted = null;


        #endregion

        #region Properties

        // Új játék kezdése parancs lekérdezése.
        public DelegateCommand NewGameCommand { get; private set; }

        // Játék betöltése parancs lekérdezése.
        public DelegateCommand LoadGameCommand { get; private set; }

        // Játék mentése parancs lekérdezése.
        public DelegateCommand SaveGameCommand { get; private set; }

        // Kilépés parancs lekérdezése.
        public DelegateCommand ExitCommand { get; private set; }

        public DelegateCommand FinishMovement { get; private set; }

        public Int32 Width { get; set; }
        public Int32 Height { get; set; }

        // Játékmező gyűjtemény lekérdezése.
        public ObservableCollection<BekeritesField> Fields { get; set; }

        
        public Int32 Size { get { return _size; } set { _size = value; OnPropertyChanged(nameof(Size)); } }
        public Int32 OccupiedAreaR { get { return _occupiedAreaR; } set { _occupiedAreaR = value; OnPropertyChanged(nameof(OccupiedAreaR)); } }
        public Int32 OccupiedAreaB { get { return _occupiedAreaB; } set { _occupiedAreaB = value; OnPropertyChanged(nameof(OccupiedAreaB)); } }


        //Játéktábla méretének lekérdezése
        public Boolean IsGameSix
        {
            get { return _model.GameMode == GameMode.x6; }
            set
            {
                if (_model.GameMode == GameMode.x6)
                    return;
                
                _model.GameMode = GameMode.x6;
                OnPropertyChanged(nameof(IsGameSix));
                OnPropertyChanged(nameof(IsGameEight));
                OnPropertyChanged(nameof(IsGameTen));
            }
        }
        public Boolean IsGameEight
        {
            get { return _model.GameMode == GameMode.x8; }
            set
            {
                if (_model.GameMode == GameMode.x8)
                    return;
                
                _model.GameMode = GameMode.x8;
                OnPropertyChanged(nameof(IsGameSix));
                OnPropertyChanged(nameof(IsGameEight));
                OnPropertyChanged(nameof(IsGameTen));
            }
        }
        public Boolean IsGameTen
        {
            get { return _model.GameMode == GameMode.x10; }
            set
            {
                if (_model.GameMode == GameMode.x10)
                    return;
                
                _model.GameMode = GameMode.x10;
                OnPropertyChanged(nameof(IsGameSix));
                OnPropertyChanged(nameof(IsGameEight));
                OnPropertyChanged(nameof(IsGameTen));
            }
        }

        #endregion

        #region Events

        // Új játék eseménye.
        public event EventHandler? NewGame;

        // Játék betöltésének eseménye.
        public event EventHandler? LoadGame;

        // Játék mentésének eseménye.
        public event EventHandler? SaveGame;

        // Játékból való kilépés eseménye.
        public event EventHandler? ExitGame;

        #endregion

        #region Constructors

        // Bekerites nézetmodell példányosítása
        public BekeritesViewModel(BekeritesGameModel model)
        {
            // játék csatlakoztatása.
            _model = model;
            _model.GameAdvanced += new EventHandler<BekeritesEventArgs>(Model_GameAdvanced);
            _model.GameWon += new EventHandler<GameWonEventArgs>(Model_GameWon);
            _model.GameOver += new EventHandler(Model_GameOver);
            _model.RotatedSecondBlock += new EventHandler<FieldChangedEventArgs>(Model_RotatedSecondBlock);
            _model.GameCreated += new EventHandler(Model_GameCreated);

            Size = _model.Table.Size;

            OccupiedAreaR = _model.OccupiedAreaR;
            OccupiedAreaB = _model.OccupiedAreaB;

            // parancsok kezelése.
            NewGameCommand = new DelegateCommand(param => OnNewGame());
            LoadGameCommand = new DelegateCommand(param => OnLoadGame());
            SaveGameCommand = new DelegateCommand(param => OnSaveGame());
            ExitCommand = new DelegateCommand(param => OnExitGame());
            FinishMovement = new DelegateCommand(param => OnFinishMovement());

            // Játéktábla létrehozása.
            Fields = new ObservableCollection<BekeritesField>();
            for (Int32 i = 0; i < _model.Table.Size; i++) // inicializáljuk a mezőket
            {
                for (Int32 j = 0; j < _model.Table.Size; j++)
                {
                    Fields.Add(new BekeritesField
                    {
                        FieldColor = Color.White,
                        X = i,
                        Y = j,
                        Number = i * _model.Table.Size + j  , // a gomb sorszáma, amelyet felhasználunk az azonosításhoz
                        StepCommand = new DelegateCommand(param => Step(Convert.ToInt32(param)))
                        // ha egy mezőre léptek, akkor jelezzük a léptetést, változtatjuk a lépésszámot  !!!NEKEM A SZÍNT KELL VÁLTOZTATNI
                    });
                }
            }
            RefreshTable();


        }

        #endregion

        #region Private methods

        // Tábla frissítése
        private void RefreshTable()
        {
            Width = 42 * _model.Table.Size;

            OnPropertyChanged(nameof(Width));

            Height = 42 * _model.Table.Size + 40;

            OnPropertyChanged(nameof(Height));

            if (Size != _model.Table.Size)
            {
                Fields.Clear();
                for (Int32 i = 0; i < _model.Table.Size; i++)
                {
                    for (Int32 j = 0; j < _model.Table.Size; j++)
                    {
                        Fields.Add(new BekeritesField
                        {
                            FieldColor = Color.White,
                            X = i,
                            Y = j,
                            Number = i * _model.Table.Size + j,
                            StepCommand = new DelegateCommand(param => Step(Convert.ToInt32(param)))
                        });
                    }
                }
            }
            Size = _model.Table.Size;

            foreach (BekeritesField field in Fields) // inicializálni kell a mezőket is
            {
                if (_model.Table[field.X, field.Y] == Player.PlayerRed)
                { 
                    field.FieldColor = Color.Red;
                }
                if (_model.Table[field.X, field.Y] == Player.PlayerBlue)
                { 
                    field.FieldColor = Color.Blue;
                }
                if (_model.Table[field.X, field.Y] == Player.PlayerRedOwned)
                { 
                    field.FieldColor = Color.IndianRed;
                }
                if (_model.Table[field.X, field.Y] == Player.PlayerBlueOwned)
                { 
                    field.FieldColor = Color.DeepSkyBlue;
                }
                if (_model.Table[field.X, field.Y] == Player.NoPlayer)
                { 
                    field.FieldColor = Color.White;
                }
            }
        }

        // Játék léptetése - eseménykiváltás
        private void Step(Int32 index)
        {            
            BekeritesField field = Fields[index];
            //_model.StepGame(field.X, field.Y);

            if (_model.Table[field.X, field.Y] == Player.PlayerRed)
            {
                field.FieldColor = Color.Red;
            }
            if (_model.Table[field.X, field.Y] == Player.PlayerBlue)
            {
                field.FieldColor = Color.Blue;
            }

            if (_model.Table[field.X, field.Y] != Player.NoPlayer)
            {
                return;
            }

            if (currentField == field)
            {
                _model.SecondBlock(field.X, field.Y);
            }
            else 
            {
                if (currentField != null)
                {
                    currentField.FieldColor = Color.White;
                }
                if(previouslyPainted != null)
                {
                    previouslyPainted.FieldColor = Color.White;
                }
                previouslyPainted = null;
                field.FieldColor = _model.Table.CurrentPlayer == Player.PlayerRed ? Color.Red : Color.Blue;
                _model.RotateCount = 0;

            }

            currentField = field;
        }

        #endregion

        #region Game event handlers

        private void Model_GameOver(object? sender, EventArgs e)
        {
            _model.NewGame();
            RefreshTable();
        }

        private void Model_GameWon(object? sender, GameWonEventArgs e)
        {
            _model.NewGame();
            RefreshTable();

        }

        private void Model_GameAdvanced(object? sender, BekeritesEventArgs e)
        {
            foreach (var coordinate in e.Coordinates)
            {
                Fields[coordinate.Key * _model.Table.Size + coordinate.Value].FieldColor = _model.Table.CurrentPlayer == Player.PlayerRed ? Color.IndianRed : Color.DeepSkyBlue;
            }

            OccupiedAreaR = _model.OccupiedAreaR;
            OccupiedAreaB = _model.OccupiedAreaB;

        }

        private void Model_RotatedSecondBlock(object? sender, FieldChangedEventArgs e)
        {
            Fields[e.X * _model.Table.Size + e.Y].FieldColor = _model.Table.CurrentPlayer == Player.PlayerRed ? Color.Red : Color.Blue;

            if (previouslyPainted != null)
            {
                previouslyPainted.FieldColor = Color.White;

            }

            previouslyPainted = Fields[e.X * _model.Table.Size + e.Y];

        }
        /// <summary>
        /// Játék létrehozásának eseménykezelője.
        /// </summary>
        private void Model_GameCreated(object? sender, EventArgs e)
        {
            RefreshTable();
            OccupiedAreaB = 0;
            OccupiedAreaR = 0;

        }


        #endregion

        #region Event methods

        //Új játék indításának eseménykiváltása.
        private void OnNewGame() 
        {
            NewGame?.Invoke(this, EventArgs.Empty);
        }

        // Játék betöltésének eseménykiváltása.
        private void OnLoadGame()
        {
            LoadGame?.Invoke(this, EventArgs.Empty);
        }

        // Játék mentésének eseménykiváltása.
        private void OnSaveGame()
        {
            SaveGame?.Invoke(this, EventArgs.Empty);
        }

        // Játék bezárásának eseménykiváltása.
        private void OnExitGame()
        {
            ExitGame?.Invoke(this, EventArgs.Empty);
        }

        private void OnFinishMovement()
        {
            if (previouslyPainted == null || currentField == null)
            {
                return;
            }

            _model.StepGame(currentField.X, currentField.Y);

            currentField = null;
            previouslyPainted = null;


        }


        #endregion
    }
}
