﻿using Bekerites.Model;
using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bekerites_WPF.ViewModel
{
    public class BekeritesField : ViewModelBase
    {
        private Color _fieldColor = Color.White;

        public Color FieldColor
        {
            get { return _fieldColor; }
            set 
            {
                if (_fieldColor != value)
                {
                    _fieldColor = value;
                    OnPropertyChanged();
                }
            }
        }

        public Int32 X { get; set; }

        public Int32 Y { get; set; }

        public Int32 Number { get; set; }

        public DelegateCommand? StepCommand { get; set; }

    }
}
