﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Bekerites_WPF.ViewModel
{
    public class DelegateCommand : ICommand
    {
        private readonly Action<Object?> _execute; // a tevékenységet végrehajtó lambda-kifejezés
        private readonly Func<Object?, Boolean>? _canExecute; // a tevékenység feltételét ellenőző lambda-kifejezés

        // Parancs létrehozása (execute -> végrehajtható tevékenység) 
        public DelegateCommand(Action<Object?> execute) : this(null, execute) { }

        public DelegateCommand(Func<Object?, Boolean>? canExecute, Action<Object?> execute)
        {
            if (execute == null)
            {
                throw new ArgumentNullException(nameof(execute));
            }

            _execute = execute;
            _canExecute = canExecute;
        }

        //Végrehajthatóság változásának eseménye.
        public event EventHandler? CanExecuteChanged;

        //Végrehajthatóság ellenőrzése. (parameter -> a tevékenység paramétere) IGAZ HA A TEVÉKENYSÉG VÉGREHAJTHATÓ
        public Boolean CanExecute(Object? parameter)
        {
            return _canExecute == null ? true : _canExecute(parameter);
        }

        //Tevékenység végrehajtása
        public void Execute(Object? parameter)
        {
            if (!CanExecute(parameter))
            {
                throw new InvalidOperationException("Command execution is disabled.");
            }
            _execute(parameter);
        }

        //Végrehajthatóság változásának eseménykiváltása.
        public void RaiseCanExecuteChanged() 
        {
            if (CanExecuteChanged != null)
            {
                CanExecuteChanged(this, EventArgs.Empty);
            }
        }
    }
}
