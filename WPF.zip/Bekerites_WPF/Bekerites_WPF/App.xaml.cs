﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Bekerites.Model;
using Bekerites.Persistence;
using Bekerites_WPF.ViewModel;
using Microsoft.Win32;

namespace Bekerites_WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        #region Fields

        private BekeritesGameModel _model = null!;
        private BekeritesViewModel _viewModel = null!;
        private MainWindow _view = null!;

        #endregion

        #region Constructors

        /// <summary>
        /// Alkalmazás példányosítása.
        /// </summary>
        public App()
        {
            Startup += new StartupEventHandler(App_Startup);
        }

        #endregion

        #region Application event handlers

        private void App_Startup(object? sender, StartupEventArgs e)
        { 
            // modell létrehozása.
            _model = new BekeritesGameModel(new BekeritesFileDataAccess());
            _model.GameWon += new EventHandler<GameWonEventArgs>(Model_GameWon);
            _model.GameOver += new EventHandler(Model_GameOver);
            _model.NewGame();

            //nézetmodell létrehozása
            _viewModel = new BekeritesViewModel(_model);
            _viewModel.NewGame += new EventHandler(ViewModel_NewGame);
            _viewModel.ExitGame += new EventHandler(ViewModel_ExitGame);
            _viewModel.LoadGame += new EventHandler(ViewModel_LoadGame);
            _viewModel.SaveGame += new EventHandler(ViewModel_SaveGame);

            //nézet létrehozása
            _view = new MainWindow();
            _view.DataContext = _viewModel;
            _view.Closing += new CancelEventHandler(View_Closing); // eseménykezelés a bezáráshoz
            _view.Show();
        }
        #endregion

        #region View event handlers

        // Nézet bezárása - eseménykezelő
        private void View_Closing(object? sender, CancelEventArgs e)
        {
            if (MessageBox.Show("Biztos, hogy ki akar lépni?", "Bekerítés", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
            {
                e.Cancel = true; // töröljük a bezárást
            }
        }

        #endregion

        #region ViewModel event handlers

        // Új játék indítása - eseménykezelő
        private void ViewModel_NewGame(object? sender, EventArgs e)
        { 
            _model.NewGame();
        }

        // Játék betöltése - eseménykezelő
        private async void ViewModel_LoadGame(object? sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog(); // dialógusablak
                openFileDialog.Title = "Bekerítés tábla betöltése";
                openFileDialog.Filter = "Bekerítés tábla|*.stl";
                if (openFileDialog.ShowDialog() == true)
                {
                    // játék betöltése
                    await _model.LoadGameAsync(openFileDialog.FileName);

                }
            }
            catch (BekeritesDataException)
            {
                MessageBox.Show("A fájl betöltése sikertelen!", "Bekerítés", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            _viewModel.OccupiedAreaR = _model.OccupiedAreaR;
            _viewModel.OccupiedAreaB = _model.OccupiedAreaB;

        }

        // Játék mentése - eseménykezelő
        private async void ViewModel_SaveGame(object? sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog(); // dialógablak
                saveFileDialog.Title = "Bekerítés tábla betöltése";
                saveFileDialog.Filter = "Bekerítés tábla|*.stl";
                if (saveFileDialog.ShowDialog() == true)
                {
                    try
                    {
                        // játéktábla mentése
                        await _model.SaveGameAsync(saveFileDialog.FileName);
                    }
                    catch (BekeritesDataException)
                    {
                        MessageBox.Show("Játék mentése sikertelen!" + Environment.NewLine + "Hibás az elérési út, vagy a könyvtár nem írható.", "Hiba!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("A fájl mentése sikertelen!", "Bekerítés", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Játékból való kilépés - eseménykezelő
        private void ViewModel_ExitGame(object? sender, EventArgs e)
        {
            _view.Close(); // ablak bezárása
        }


        #endregion

        #region Model event handlers

        private void Model_GameWon(object? sender, GameWonEventArgs e)
        {

            switch (e.Player)
            {
                case Player.PlayerRed:
                    MessageBox.Show("A piros játékos győzött!", "Játék vége!", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    break;
                case Player.PlayerBlue:
                    MessageBox.Show("A kék játékos győzött!", "Játék vége!", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    break;
            }
        }

        private void Model_GameOver(object? sender, EventArgs e)
        {

            MessageBox.Show("Döntetlen játék!", "Játék vége!", MessageBoxButton.OK, MessageBoxImage.Asterisk);
        }


        #endregion

    }

}
