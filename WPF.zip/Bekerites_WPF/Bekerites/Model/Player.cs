﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bekerites.Model
{
    public enum Player
    {
        NoPlayer,
        PlayerRed,
        PlayerBlue,
        PlayerRedOwned,
        PlayerBlueOwned
    }
}
