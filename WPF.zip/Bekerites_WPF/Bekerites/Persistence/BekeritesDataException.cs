﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bekerites.Persistence
{
    public class BekeritesDataException : Exception
    {
        public BekeritesDataException() { }
    }
}
